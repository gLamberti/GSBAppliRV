package fr.berufood.foody.vues;

import javax.swing.JPanel;

public class VueAccueil extends JPanel {
	
	public VueAccueil(){
		super() ;

	}

}