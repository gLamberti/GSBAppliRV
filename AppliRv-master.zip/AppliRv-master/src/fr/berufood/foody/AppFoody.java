package fr.berufood.foody;

import fr.berufood.foody.vues.VueFoody;

public class AppFoody {

	public static void main(String[] args) {
		new VueFoody() ;
	}

}
