package fr.berufood.foody.controleurs;


import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import fr.berufood.foody.modeles.ModeleFoody;
import fr.berufood.foody.rendus.TablePanelRapportDateVisiteur;



public class ControleurRapportVisiteur {
	
	// Vue associée au contrôleur
	//private Produit vue ;					
	
	
	

}